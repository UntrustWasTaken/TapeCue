﻿

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.Windows.Media;
using System.IO;
using FFMpegCore;
using System.Timers;
using System.Threading;

namespace TapeCue
{
    public partial class Form1 : Form
    {
        SoundPlayer simpleSound = new SoundPlayer(@"c:\Windows\Media\chimes.wav");

        MediaPlayer player = new MediaPlayer();

        private MediaPlayer currentPlayer = new MediaPlayer();
        //private MediaPlayer nextPlayer = new MediaPlayer();

        List<string> validExtensions = new List<string>(new string[] { ".mp3", ".wav", ".flac", ".ogg" });

        private System.Windows.Forms.Timer scrubTimer;
        private bool isScrubbing = false;

        private ListBox activeListBox = null;


        public Form1()
        {
            InitializeComponent();
            
            listBoxA.DisplayMember = "FileName";
            listBoxB.DisplayMember = "FileName";

            scrubTimer = new System.Windows.Forms.Timer();
            scrubTimer.Interval = 100; // ms
            scrubTimer.Tick += ScrubTimer_Tick;

            ToolTip toolTip1 = new ToolTip();
            toolTip1.SetToolTip(btnMerge, "Merge all the tracks into one audio file.");


            //warm up the media player.
            var warmup = new MediaPlayer();
            warmup.Open(new Uri(@"c:\Windows\Media\chimes.wav"));
            warmup.Volume = 0;
            warmup.Play();
            warmup.Stop();
            warmup.Close();
        }

        private void HandleDragDropFile(object sender, DragEventArgs e)
        {
            ListBox listBox = ((ListBox)sender);
            Console.WriteLine(listBox.Name);

            if (e.Data.GetDataPresent(DataFormats.FileDrop)) //If it was a file that was dropped
            {
                Array filenames = (Array)e.Data.GetData(DataFormats.FileDrop); //Get the file path + name of ALL the selected files

                foreach (string s in filenames) //Output each
                {
                    string extension = Path.GetExtension(s);

                    if (validExtensions.Contains(extension))
                    {
                        Console.WriteLine($"Added file {s}");
                        //sideA.Add(new Track(s));

                        Track newTrack = new Track(s);

                        //listBoxA.Items.Add(newTrack);
                        listBox.Items.Add(newTrack);
                      
                        UpdateListLabels();
                    }
                    else
                    {
                        Console.WriteLine($"Invalid extension {extension}, {s}");
                        lblStatus.Text = ($"Invalid extension {extension}, {s}");
                    }
                }

                if(filenames.Length > 0)
                {
                    lblStatus.Text = ($"Added {filenames.Length} track(s)");
                }

                e.Effect = DragDropEffects.Copy; //Allow drop
            }

            else //Not a file, or we are reordering
            {
                //Console.WriteLine("File not recognised."); //Debug

                if (listBox.Items.Count != 1) //IDK
                {
                    Point point = listBox.PointToClient(new Point(e.X, e.Y));
                    int index = listBox.IndexFromPoint(point);
                    if (index < 0) index = listBox.Items.Count - 1;

                    object data = e.Data.GetData(typeof(Track));

                    listBox.Items.Remove(data);
                    listBox.Items.Insert(index, data);
                }
            }
        }

        private void UpdateListLabels()
        {
            TimeSpan duration = CalculateSideDuration(listBoxA);
            lblSideA.Text = $"Side A {duration.Hours.ToString()}:{duration.Minutes.ToString()}:{duration.Seconds.ToString()}";
            duration = CalculateSideDuration(listBoxB);
            lblSideB.Text = $"Side B {duration.Hours.ToString()}:{duration.Minutes.ToString()}:{duration.Seconds.ToString()}";
        }

      
        private void HandleListBoxMouseDown(object sender, MouseEventArgs e)
        {
            ListBox listBox = ((ListBox)sender);
            if (listBox.SelectedItem == null) return;

            listBox.DoDragDrop(listBox.SelectedItem, DragDropEffects.Move);
            Track currentTrack = (Track)listBox.SelectedItem;

            //need to make sure only one can be selected at a time
            if (listBox.Name == "listBoxA")
            {
                listBoxB.SelectedItem = null;
            }
            else
            {
                listBoxA.SelectedItem = null;
            }
        }

        private void listBoxA_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void ScrubTimer_Tick(object sender, EventArgs e)
        {
            
            Track currentTrack = (Track)activeListBox.SelectedItem;

            if (currentTrack == null || isScrubbing)
            {
                return;
            }

            double durationMs = currentTrack.Duration.TotalMilliseconds;
            double positionMs = currentPlayer.Position.TotalMilliseconds;

            if (durationMs <= 0)
            {
                return;
            }

            double progress = positionMs / durationMs;
            int value = (int)(progress * trackBarScrub.Maximum);

            value = Math.Max(trackBarScrub.Minimum,
                             Math.Min(trackBarScrub.Maximum, value));

            trackBarScrub.Value = value;
        }

        private ListBox GetCurrentSide()
        {
            //Determine which side we are on
            if (listBoxA.SelectedIndex != -1)
            {
                //Console.WriteLine("A");
                return listBoxA;
            }
            else if (listBoxB.SelectedIndex != -1)
            {
                //Console.WriteLine("B");
                return listBoxB;
            }
            return null;
        }

        private async void PlayNextTrack(ListBox listBox)
        {

            if (listBox.Items.Count == 0)
                return;

            activeListBox = listBox;

            if (listBox.SelectedIndex == -1)
                listBox.SelectedIndex = 0;

            Track track = (Track)listBox.SelectedItem;

            // HARD RESET (this matters)
            currentPlayer.MediaEnded -= MediaEnd;
            currentPlayer.Stop();
            currentPlayer.Close();

            if (checkBoxGap.Checked &&
                int.TryParse(txtGap.Text, out int gapMs))
            {
                await Task.Delay(gapMs);
            }

            ResetScrubBar();
            currentPlayer.Balance = (float)trackBarBalance.Value / 100;

            float value = (float)trackBar1.Value; //Get the raw 0 - 100 slider value

            lblProgVolume.Text = value.ToString(); //Set the label

            if (checkBoxLogScale.Checked)
            {
                value = ConvertToSquaredVolume(value, trackBar1.Maximum); //Convert to "log" scale, map 0 to 1
            }
            else
            {
                value = value / 100;
            }

            currentPlayer.Volume = value; //Set the player volume

            currentPlayer.Open(new Uri(track.FilePath));
            currentPlayer.MediaEnded += MediaEnd;
            currentPlayer.Play();

            scrubTimer.Start();
        }

        public void MediaEnd(object sender, EventArgs e)
        {
            if (activeListBox == null)
                return;

            if (activeListBox.SelectedIndex < activeListBox.Items.Count - 1)
            {
                activeListBox.SelectedIndex++;
                PlayNextTrack(activeListBox);
            }
            else
            {
                StopPlayback();
                activeListBox.SelectedIndex = -1;
                activeListBox = null;
            }
        }

        public TimeSpan CalculateSideDuration(ListBox listBox)
        {
            TimeSpan time = new TimeSpan(0, 0, 0);
            
                foreach (Track t in listBox.Items)
                {
                    time += t.Duration;
                }

                if (checkBoxGap.Checked && txtGap.Text != "")
                {
                    TimeSpan tgap = new TimeSpan(0, 0, (int.Parse(txtGap.Text) / 1000) * listBox.Items.Count);
                    time += tgap;
                    Console.WriteLine("total tgap = " + tgap.ToString() + " has " + listBox.Items.Count + " items, delay " + int.Parse(txtGap.Text) / 1000);
                }
           
            return time;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StopPlayback();
            listBoxA.SelectedIndex = -1;
            listBoxB.SelectedIndex = -1;
        }

        private void StopPlayback()
        {
            scrubTimer.Stop();

            currentPlayer.MediaEnded -= MediaEnd;
            currentPlayer.Stop();
            currentPlayer.Close();

            ResetScrubBar();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            float value = (float)trackBar1.Value; //Get the raw 0 - 100 slider value

            lblProgVolume.Text = value.ToString(); //Set the label

            if (checkBoxLogScale.Checked)
            {
                value = ConvertToSquaredVolume(value, trackBar1.Maximum); //Convert to "log" scale, map 0 to 1
            }
            else
            {
                value = value / 100;
            }
            
            currentPlayer.Volume = value; //Set the player volume
            Console.WriteLine(value);
        }

        public static float ConvertToSquaredVolume(float sliderValue, float maxSliderValue)// Square the slider value and normalize to 0-1 range
        {
            float squaredVolume = (sliderValue * sliderValue) / (maxSliderValue * maxSliderValue);
            return squaredVolume;
        }

        private void trackBarBalance_Scroll(object sender, EventArgs e)
        {
            currentPlayer.Balance = (float)trackBarBalance.Value / 100;
        }



        private void listBoxA_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnDelSel.Enabled = true;
            Console.WriteLine("selected index changed A");
        }



        private void btnTone_Click(object sender, EventArgs e)
        {
            //Console.Beep(int.Parse(txtFreq.Text), int.Parse(txtToneDuration.Text) * 1000);

            string s = GenerateToneWav(int.Parse(txtFreq.Text), int.Parse(txtToneDuration.Text));
            Track newTrack = new Track(s);

            listBoxA.Items.Add(newTrack);
            UpdateListLabels();
        }

        private void btnToneB_Click(object sender, EventArgs e)
        {
            string s = GenerateToneWav(int.Parse(txtFreq.Text), int.Parse(txtToneDuration.Text));
            Track newTrack = new Track(s);

            listBoxB.Items.Add(newTrack);
            UpdateListLabels();
        }

        private string GenerateToneWav(int frequency, int durationMs)
        {
            int sampleRate = 44100;
            short bitsPerSample = 16;
            short channels = 1;

            int samples = sampleRate * durationMs / 1000;
            //string path = Path.Combine(Path.GetTempPath(), $"tone_{frequency}_{durationMs}.wav");

            Directory.CreateDirectory(Path.Combine(Path.GetTempPath(), "TapeCue"));

            string path = Path.Combine(
                Path.GetTempPath(),
                "TapeCue",
                $"tone_{frequency}_{durationMs}.wav"
            );


            using (var fs = new FileStream(path, FileMode.Create))
            using (var bw = new BinaryWriter(fs))
            {
                // RIFF header
                bw.Write(Encoding.ASCII.GetBytes("RIFF"));
                bw.Write(36 + samples * 2);
                bw.Write(Encoding.ASCII.GetBytes("WAVE"));

                // fmt chunk
                bw.Write(Encoding.ASCII.GetBytes("fmt "));
                bw.Write(16);
                bw.Write((short)1); // PCM
                bw.Write(channels);
                bw.Write(sampleRate);
                bw.Write(sampleRate * channels * bitsPerSample / 8);
                bw.Write((short)(channels * bitsPerSample / 8));
                bw.Write(bitsPerSample);

                // data chunk
                bw.Write(Encoding.ASCII.GetBytes("data"));
                bw.Write(samples * 2);

                double amplitude = 0.25 * short.MaxValue;
                double theta = 2 * Math.PI * frequency / sampleRate;

                for (int i = 0; i < samples; i++)
                {
                    short sample = (short)(amplitude * Math.Sin(theta * i));
                    bw.Write(sample);
                }
            }

            return path;
        }

        private void checkBoxGap_CheckedChanged(object sender, EventArgs e)
        {
            txtGap.Enabled = checkBoxGap.Checked;
            UpdateListLabels();
        }

        private void txtGap_TextChanged(object sender, EventArgs e) //Validate input, update labels / duration
        {
            UpdateListLabels();
        }

        private void txtGap_KeyPress(object sender, KeyPressEventArgs e) //Reject any non numerical inputs
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);

        }

        private void listBoxA_DoubleClick(object sender, EventArgs e)
        {
            //MessageBox.Show(listBoxA.SelectedItem.ToString());
        }


        private void trackBarScrub_MouseDown(object sender, MouseEventArgs e)
        {
            isScrubbing = true;
        }

        private void trackBarScrub_MouseUp(object sender, MouseEventArgs e)
        {
            ListBox listBox = GetCurrentSide();
            if (listBox == null) { return; }

            Track currentTrack = (Track)listBox.SelectedItem;

            //Track currentTrack = (Track)listBoxA.SelectedItem;

            if (currentTrack == null)
            {
                isScrubbing = false;
                return;
            }

            double percent = (double)trackBarScrub.Value / trackBarScrub.Maximum;
            double newMs = currentTrack.Duration.TotalMilliseconds * percent;

            currentPlayer.Position = TimeSpan.FromMilliseconds(newMs);
            isScrubbing = false;
        }

        private void ResetScrubBar()
        {
            trackBarScrub.Value = 0;
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            ListBox listBox = GetCurrentSide();
            if (listBox != null)
            {
                if (listBox.SelectedIndex > 0)
                {
                    listBox.SelectedIndex -= 1;
                }
                PlayNextTrack(listBox);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            ListBox listBox = GetCurrentSide();
            if (listBox != null)
            {
                if (listBox.SelectedIndex < listBox.Items.Count -1)
                {
                    listBox.SelectedIndex += 1;
                }
                PlayNextTrack(listBox);
            }
        }

        private void saveProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Title = "Save TapeCue Project";
                sfd.Filter = "CSV Files (*.csv)|*.csv";
                sfd.DefaultExt = "csv";
                sfd.AddExtension = true;

                if (sfd.ShowDialog() != DialogResult.OK)
                    return;

                using (StreamWriter writer = new StreamWriter(sfd.FileName, false, Encoding.UTF8))
                {
                    

                    // Side A
                    foreach (Track track in listBoxA.Items)
                    {
                        writer.WriteLine($"A,\"{track.FilePath}\"");
                    }

                    // Side B
                    foreach (Track track in listBoxB.Items)
                    {
                        writer.WriteLine($"B,\"{track.FilePath}\"");
                    }
                }
            }
            lblStatus.Text = "File saved.";
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            player.Stop();
            scrubTimer.Stop();

            listBoxA.Items.Clear();
            listBoxB.Items.Clear();
            lblSideA.Text = "Side A 00:00:00";
            lblSideB.Text = "Side B 00:00:00";

            StopPlayback();
        }

        private void btnDelSel_Click(object sender, EventArgs e)
        {
            if(listBoxA.SelectedIndex != -1)
            {
                listBoxA.Items.Remove(listBoxA.SelectedItem);
            }

            if (listBoxB.SelectedIndex != -1)
            {
                listBoxB.Items.Remove(listBoxA.SelectedItem);
            }

            //todo fix for b
        }

        private void listBoxA_SelectedValueChanged(object sender, EventArgs e)
        {
            Console.WriteLine("selectred value changed A ");
        }

        private void btnStartA_Click(object sender, EventArgs e)
        {
            listBoxB.SelectedIndex = -1; //clear any selection in B
            PlayNextTrack(listBoxA);
        }

        private void btnStartB_Click(object sender, EventArgs e)
        {
                listBoxA.SelectedIndex = -1; //clear any selection in A
            PlayNextTrack(listBoxB);
            
        }

        private void btnMerge_Click(object sender, EventArgs e)
        {
            // Get all tracks from A and B
            var tracks = new List<Track>();
            tracks.AddRange(listBoxA.Items.Cast<Track>());
           // tracks.AddRange(listBoxB.Items.Cast<Track>());

            if (tracks.Count == 0)
            {
                MessageBox.Show("No tracks to merge.");
                return;
            }

            // Create temp folder if it doesn't exist
            string tempFolder = Path.Combine(Path.GetTempPath(), "TapeCue");
            Directory.CreateDirectory(tempFolder);

            // Generate output filename
            string outputPath = Path.Combine(tempFolder, $"Merged_{DateTime.Now:yyyyMMdd_HHmmss}_A.wav");

            try
            {
                // Build an array of file paths
                string[] inputPaths = tracks.Select(t => t.FilePath).ToArray();

                // Use FFMpeg to concatenate audio files
                // First, create a temporary text file listing all inputs
                string listFile = Path.Combine(tempFolder, "merge_list.txt");
                File.WriteAllLines(listFile, inputPaths.Select(p => $"file '{p.Replace("\\", "/")}'"));

                // Run FFMpeg concat
                FFMpegArguments
                    .FromFileInput(listFile, true, options => options.WithCustomArgument("-f concat -safe 0"))
                    .OutputToFile(outputPath, true, options => options
                        .WithAudioCodec("pcm_s16le")   // WAV PCM
                        .WithCustomArgument("-y")      // overwrite
                    )
                    .ProcessSynchronously();

                // Clear previous tracks
                listBoxA.Items.Clear();
               

                // Add new merged track to listBoxA
                Track mergedTrack = new Track(outputPath);
                listBoxA.Items.Add(mergedTrack);

                UpdateListLabels();

                //MessageBox.Show($"Merged audio saved to {outputPath}");
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Error merging audio: " + ex.Message);
            }

            // Get all tracks from A and B
             tracks = new List<Track>();
           // tracks.AddRange(listBoxA.Items.Cast<Track>());
            tracks.AddRange(listBoxB.Items.Cast<Track>());

            if (tracks.Count == 0)
            {
                MessageBox.Show("No tracks to merge.");
                return;
            }

            // Create temp folder if it doesn't exist
            tempFolder = Path.Combine(Path.GetTempPath(), "TapeCue");
            Directory.CreateDirectory(tempFolder);

            // Generate output filename
            outputPath = Path.Combine(tempFolder, $"Merged_{DateTime.Now:yyyyMMdd_HHmmss}_B.wav");

            try
            {
                // Build an array of file paths
                string[] inputPaths = tracks.Select(t => t.FilePath).ToArray();

                // Use FFMpeg to concatenate audio files
                // First, create a temporary text file listing all inputs
                string listFile = Path.Combine(tempFolder, "merge_list.txt");
                File.WriteAllLines(listFile, inputPaths.Select(p => $"file '{p.Replace("\\", "/")}'"));

                // Run FFMpeg concat
                FFMpegArguments
                    .FromFileInput(listFile, true, options => options.WithCustomArgument("-f concat -safe 0"))
                    .OutputToFile(outputPath, true, options => options
                        .WithAudioCodec("pcm_s16le")   // WAV PCM
                        .WithCustomArgument("-y")      // overwrite
                    )
                    .ProcessSynchronously();

                // Clear previous tracks
                
                listBoxB.Items.Clear();

                // Add new merged track to listBoxA
                Track mergedTrack = new Track(outputPath);
                listBoxB.Items.Add(mergedTrack);

                UpdateListLabels();

                MessageBox.Show($"Merged audio saved to {outputPath}");
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Error merging audio: " + ex.Message);
            }

            MessageBox.Show("Merged.");
        }

        private void btnPurge_Click(object sender, EventArgs e)
        {
            string tempFolder = Path.Combine(Path.GetTempPath(), "TapeCue");

            if (!Directory.Exists(tempFolder))
            {
                return;
            }

            try
            {
                // Delete all files in the folder
                DirectoryInfo di = new DirectoryInfo(tempFolder);
                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }

                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    dir.Delete(true); // recursively delete subfolders if any
                }

                MessageBox.Show("Temp folder cleared successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error clearing temp folder: " + ex.Message);
            }
        }

        private void lblSideA_Click(object sender, EventArgs e)
        {

        }

        private void openProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "Load TapeCue Project";
                ofd.Filter = "CSV Files (*.csv)|*.csv";
                ofd.Multiselect = false;

                if (ofd.ShowDialog() != DialogResult.OK)
                    return;

                // Clear existing tracks
                listBoxA.Items.Clear();
                listBoxB.Items.Clear();

                string[] lines = File.ReadAllLines(ofd.FileName, Encoding.UTF8);

                foreach (string line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    // Split into Side + Path (path may contain commas)
                    string[] parts = line.Split(new[] { ',' }, 2);

                    if (parts.Length != 2)
                        continue;

                    char side = parts[0].Trim().ToUpperInvariant()[0];
                    string filePath = parts[1].Trim().Trim('"');

                    if (!File.Exists(filePath))
                    {
                        Console.WriteLine($"Missing file: {filePath}");
                        continue;
                    }

                    Console.WriteLine($"Added file {filePath}");

                    Track newTrack = new Track(filePath);

                    if (side == 'A')
                        listBoxA.Items.Add(newTrack);
                    else if (side == 'B')
                        listBoxB.Items.Add(newTrack);
                }
            }
            lblStatus.Text = "File loaded.";
            UpdateListLabels();
        }
    }

    public class Track
    {
        private string filePath;
        private TimeSpan length;
        private DateTime lastAccess;

        public Track(string path)
        {
            filePath = path;

            var mediaInfo = FFProbe.Analyse(filePath);
            length = mediaInfo.Duration;
            Console.WriteLine(mediaInfo.Duration.ToString());
            lastAccess = File.GetLastWriteTime(filePath);

        }

        public string FileName
        {
            get
            {
                return Path.GetFileName(filePath);
            }
        }

        public string FilePath
        {
            get
            {
                return filePath;
            }
        }
        public TimeSpan Duration
        {
            get
            {
                return length;
            }
        }
        public DateTime LastAccessed
        {
            get
            {
                return lastAccess;
            }
        }


    }

}

