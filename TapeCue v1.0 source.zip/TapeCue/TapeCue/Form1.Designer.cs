﻿
namespace TapeCue
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openProjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveProjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabOptions = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtGap = new System.Windows.Forms.TextBox();
            this.checkBoxGap = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnMerge = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnToneB = new System.Windows.Forms.Button();
            this.btnToneA = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtToneDuration = new System.Windows.Forms.TextBox();
            this.txtFreq = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnPurge = new System.Windows.Forms.Button();
            this.checkBoxLogScale = new System.Windows.Forms.CheckBox();
            this.checkBoxFlashWindow = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tabTracks = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.btnStartB = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.trackBarScrub = new System.Windows.Forms.TrackBar();
            this.btnStartA = new System.Windows.Forms.Button();
            this.btnDelSel = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.listBoxA = new System.Windows.Forms.ListBox();
            this.lblSideB = new System.Windows.Forms.Label();
            this.lblSideA = new System.Windows.Forms.Label();
            this.listBoxB = new System.Windows.Forms.ListBox();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.trackBarBalance = new System.Windows.Forms.TrackBar();
            this.lblProgVolume = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.menuStrip1.SuspendLayout();
            this.tabOptions.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabTracks.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarScrub)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(684, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openProjectToolStripMenuItem,
            this.saveProjectToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openProjectToolStripMenuItem
            // 
            this.openProjectToolStripMenuItem.Name = "openProjectToolStripMenuItem";
            this.openProjectToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.openProjectToolStripMenuItem.Text = "Open Project";
            this.openProjectToolStripMenuItem.Click += new System.EventHandler(this.openProjectToolStripMenuItem_Click);
            // 
            // saveProjectToolStripMenuItem
            // 
            this.saveProjectToolStripMenuItem.Name = "saveProjectToolStripMenuItem";
            this.saveProjectToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.saveProjectToolStripMenuItem.Text = "Save Project";
            this.saveProjectToolStripMenuItem.Click += new System.EventHandler(this.saveProjectToolStripMenuItem_Click);
            // 
            // tabOptions
            // 
            this.tabOptions.Controls.Add(this.tableLayoutPanel2);
            this.tabOptions.Location = new System.Drawing.Point(4, 22);
            this.tabOptions.Name = "tabOptions";
            this.tabOptions.Padding = new System.Windows.Forms.Padding(3);
            this.tabOptions.Size = new System.Drawing.Size(676, 381);
            this.tabOptions.TabIndex = 1;
            this.tabOptions.Text = "Options / Utilities";
            this.tabOptions.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.groupBox4, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox6, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.groupBox3, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox5, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label11, 2, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.86666F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.13333F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(670, 375);
            this.tableLayoutPanel2.TabIndex = 7;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.txtGap);
            this.groupBox4.Controls.Add(this.checkBoxGap);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(5, 5);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 116);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Intervals";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(112, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "[ms]";
            // 
            // txtGap
            // 
            this.txtGap.Enabled = false;
            this.txtGap.Location = new System.Drawing.Point(6, 52);
            this.txtGap.Name = "txtGap";
            this.txtGap.Size = new System.Drawing.Size(100, 20);
            this.txtGap.TabIndex = 2;
            this.txtGap.Text = "4000";
            this.txtGap.TextChanged += new System.EventHandler(this.txtGap_TextChanged);
            this.txtGap.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGap_KeyPress);
            // 
            // checkBoxGap
            // 
            this.checkBoxGap.Location = new System.Drawing.Point(6, 19);
            this.checkBoxGap.Name = "checkBoxGap";
            this.checkBoxGap.Size = new System.Drawing.Size(168, 24);
            this.checkBoxGap.TabIndex = 4;
            this.checkBoxGap.Text = "Add a gap between tracks";
            this.checkBoxGap.CheckedChanged += new System.EventHandler(this.checkBoxGap_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnMerge);
            this.groupBox6.Location = new System.Drawing.Point(5, 131);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(200, 56);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Gapless playback";
            // 
            // btnMerge
            // 
            this.btnMerge.Location = new System.Drawing.Point(6, 19);
            this.btnMerge.Name = "btnMerge";
            this.btnMerge.Size = new System.Drawing.Size(188, 23);
            this.btnMerge.TabIndex = 0;
            this.btnMerge.Text = "Merge all tracks";
            this.btnMerge.UseVisualStyleBackColor = true;
            this.btnMerge.Click += new System.EventHandler(this.btnMerge_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnToneB);
            this.groupBox3.Controls.Add(this.btnToneA);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txtToneDuration);
            this.groupBox3.Controls.Add(this.txtFreq);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(213, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 120);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Test tones";
            // 
            // btnToneB
            // 
            this.btnToneB.Location = new System.Drawing.Point(105, 91);
            this.btnToneB.Name = "btnToneB";
            this.btnToneB.Size = new System.Drawing.Size(89, 23);
            this.btnToneB.TabIndex = 6;
            this.btnToneB.Text = "Add to B";
            this.btnToneB.UseVisualStyleBackColor = true;
            // 
            // btnToneA
            // 
            this.btnToneA.Location = new System.Drawing.Point(12, 91);
            this.btnToneA.Name = "btnToneA";
            this.btnToneA.Size = new System.Drawing.Size(87, 23);
            this.btnToneA.TabIndex = 5;
            this.btnToneA.Text = "Add to A";
            this.btnToneA.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Duration [ms]";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Frequency [Hz]";
            // 
            // txtToneDuration
            // 
            this.txtToneDuration.Location = new System.Drawing.Point(94, 55);
            this.txtToneDuration.Name = "txtToneDuration";
            this.txtToneDuration.Size = new System.Drawing.Size(100, 20);
            this.txtToneDuration.TabIndex = 2;
            this.txtToneDuration.Text = "1000";
            // 
            // txtFreq
            // 
            this.txtFreq.Location = new System.Drawing.Point(94, 29);
            this.txtFreq.Name = "txtFreq";
            this.txtFreq.Size = new System.Drawing.Size(100, 20);
            this.txtFreq.TabIndex = 1;
            this.txtFreq.Text = "3000";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnPurge);
            this.groupBox5.Controls.Add(this.checkBoxLogScale);
            this.groupBox5.Controls.Add(this.checkBoxFlashWindow);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(419, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(248, 120);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Application settings";
            // 
            // btnPurge
            // 
            this.btnPurge.Location = new System.Drawing.Point(6, 91);
            this.btnPurge.Name = "btnPurge";
            this.btnPurge.Size = new System.Drawing.Size(236, 23);
            this.btnPurge.TabIndex = 7;
            this.btnPurge.Text = "Delete temp files";
            this.btnPurge.UseVisualStyleBackColor = true;
            // 
            // checkBoxLogScale
            // 
            this.checkBoxLogScale.AutoSize = true;
            this.checkBoxLogScale.Checked = true;
            this.checkBoxLogScale.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxLogScale.Location = new System.Drawing.Point(6, 19);
            this.checkBoxLogScale.Name = "checkBoxLogScale";
            this.checkBoxLogScale.Size = new System.Drawing.Size(149, 17);
            this.checkBoxLogScale.TabIndex = 3;
            this.checkBoxLogScale.Text = "Logarithmic volume sliders";
            this.checkBoxLogScale.UseVisualStyleBackColor = true;
            // 
            // checkBoxFlashWindow
            // 
            this.checkBoxFlashWindow.AutoSize = true;
            this.checkBoxFlashWindow.Checked = true;
            this.checkBoxFlashWindow.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxFlashWindow.Enabled = false;
            this.checkBoxFlashWindow.Location = new System.Drawing.Point(6, 42);
            this.checkBoxFlashWindow.Name = "checkBoxFlashWindow";
            this.checkBoxFlashWindow.Size = new System.Drawing.Size(192, 17);
            this.checkBoxFlashWindow.TabIndex = 0;
            this.checkBoxFlashWindow.Text = "Flash window when complete (NYI)";
            this.checkBoxFlashWindow.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Enabled = false;
            this.label11.Location = new System.Drawing.Point(577, 362);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 13);
            this.label11.TabIndex = 16;
            this.label11.Text = "untrust2033 2025";
            // 
            // tabTracks
            // 
            this.tabTracks.Controls.Add(this.label10);
            this.tabTracks.Controls.Add(this.lblStatus);
            this.tabTracks.Controls.Add(this.groupBox7);
            this.tabTracks.Controls.Add(this.btnDelSel);
            this.tabTracks.Controls.Add(this.groupBox2);
            this.tabTracks.Controls.Add(this.btnClearAll);
            this.tabTracks.Controls.Add(this.groupBox1);
            this.tabTracks.Location = new System.Drawing.Point(4, 22);
            this.tabTracks.Name = "tabTracks";
            this.tabTracks.Padding = new System.Windows.Forms.Padding(3);
            this.tabTracks.Size = new System.Drawing.Size(676, 381);
            this.tabTracks.TabIndex = 0;
            this.tabTracks.Text = "Tracks";
            this.tabTracks.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Enabled = false;
            this.label10.Location = new System.Drawing.Point(575, 363);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 13);
            this.label10.TabIndex = 15;
            this.label10.Text = "untrust2033 2025";
            // 
            // lblStatus
            // 
            this.lblStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(14, 346);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(195, 13);
            this.lblStatus.TabIndex = 14;
            this.lblStatus.Text = "No tracks loaded, drag some in to begin";
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.btnNext);
            this.groupBox7.Controls.Add(this.btnPrev);
            this.groupBox7.Controls.Add(this.btnStartB);
            this.groupBox7.Controls.Add(this.btnStop);
            this.groupBox7.Controls.Add(this.trackBarScrub);
            this.groupBox7.Controls.Add(this.btnStartA);
            this.groupBox7.Location = new System.Drawing.Point(465, 207);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(200, 157);
            this.groupBox7.TabIndex = 13;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Playback";
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(151, 105);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(33, 34);
            this.btnNext.TabIndex = 15;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrev
            // 
            this.btnPrev.Location = new System.Drawing.Point(18, 105);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(33, 34);
            this.btnPrev.TabIndex = 14;
            this.btnPrev.Text = "<";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // btnStartB
            // 
            this.btnStartB.Location = new System.Drawing.Point(18, 64);
            this.btnStartB.Name = "btnStartB";
            this.btnStartB.Size = new System.Drawing.Size(80, 35);
            this.btnStartB.TabIndex = 13;
            this.btnStartB.Text = "Start B";
            this.btnStartB.UseVisualStyleBackColor = true;
            this.btnStartB.Click += new System.EventHandler(this.btnStartB_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(104, 19);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(80, 80);
            this.btnStop.TabIndex = 6;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.button1_Click);
            // 
            // trackBarScrub
            // 
            this.trackBarScrub.BackColor = System.Drawing.SystemColors.Window;
            this.trackBarScrub.Location = new System.Drawing.Point(46, 109);
            this.trackBarScrub.Maximum = 1000;
            this.trackBarScrub.Name = "trackBarScrub";
            this.trackBarScrub.Size = new System.Drawing.Size(104, 45);
            this.trackBarScrub.TabIndex = 12;
            this.trackBarScrub.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBarScrub.MouseDown += new System.Windows.Forms.MouseEventHandler(this.trackBarScrub_MouseDown);
            this.trackBarScrub.MouseUp += new System.Windows.Forms.MouseEventHandler(this.trackBarScrub_MouseUp);
            // 
            // btnStartA
            // 
            this.btnStartA.Location = new System.Drawing.Point(18, 19);
            this.btnStartA.Name = "btnStartA";
            this.btnStartA.Size = new System.Drawing.Size(80, 35);
            this.btnStartA.TabIndex = 4;
            this.btnStartA.Text = "Start A";
            this.btnStartA.UseVisualStyleBackColor = true;
            this.btnStartA.Click += new System.EventHandler(this.btnStartA_Click);
            // 
            // btnDelSel
            // 
            this.btnDelSel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelSel.Location = new System.Drawing.Point(341, 341);
            this.btnDelSel.Name = "btnDelSel";
            this.btnDelSel.Size = new System.Drawing.Size(105, 23);
            this.btnDelSel.TabIndex = 10;
            this.btnDelSel.Text = "Delete selected";
            this.btnDelSel.UseVisualStyleBackColor = true;
            this.btnDelSel.Click += new System.EventHandler(this.btnDelSel_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.tableLayoutPanel1);
            this.groupBox2.Location = new System.Drawing.Point(8, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(438, 329);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tracks";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.listBoxA, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblSideB, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblSideA, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.listBoxB, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.56579F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 92.43421F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(432, 310);
            this.tableLayoutPanel1.TabIndex = 14;
            // 
            // listBoxA
            // 
            this.listBoxA.AllowDrop = true;
            this.listBoxA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxA.FormattingEnabled = true;
            this.listBoxA.Location = new System.Drawing.Point(3, 26);
            this.listBoxA.Name = "listBoxA";
            this.listBoxA.Size = new System.Drawing.Size(210, 281);
            this.listBoxA.TabIndex = 0;
            this.listBoxA.DragDrop += new System.Windows.Forms.DragEventHandler(this.HandleDragDropFile);
            this.listBoxA.DragOver += new System.Windows.Forms.DragEventHandler(this.listBoxA_DragOver);
            this.listBoxA.DoubleClick += new System.EventHandler(this.listBoxA_DoubleClick);
            this.listBoxA.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HandleListBoxMouseDown);
            // 
            // lblSideB
            // 
            this.lblSideB.AutoSize = true;
            this.lblSideB.Location = new System.Drawing.Point(219, 0);
            this.lblSideB.Name = "lblSideB";
            this.lblSideB.Size = new System.Drawing.Size(83, 13);
            this.lblSideB.TabIndex = 3;
            this.lblSideB.Text = "Side B 00:00:00";
            // 
            // lblSideA
            // 
            this.lblSideA.AutoSize = true;
            this.lblSideA.Location = new System.Drawing.Point(3, 0);
            this.lblSideA.Name = "lblSideA";
            this.lblSideA.Size = new System.Drawing.Size(83, 13);
            this.lblSideA.TabIndex = 2;
            this.lblSideA.Text = "Side A 00:00:00";
            this.lblSideA.Click += new System.EventHandler(this.lblSideA_Click);
            // 
            // listBoxB
            // 
            this.listBoxB.AllowDrop = true;
            this.listBoxB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxB.FormattingEnabled = true;
            this.listBoxB.Location = new System.Drawing.Point(219, 26);
            this.listBoxB.Name = "listBoxB";
            this.listBoxB.Size = new System.Drawing.Size(210, 281);
            this.listBoxB.TabIndex = 11;
            this.listBoxB.DragDrop += new System.Windows.Forms.DragEventHandler(this.HandleDragDropFile);
            this.listBoxB.DragOver += new System.Windows.Forms.DragEventHandler(this.listBoxA_DragOver);
            this.listBoxB.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HandleListBoxMouseDown);
            // 
            // btnClearAll
            // 
            this.btnClearAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClearAll.Location = new System.Drawing.Point(260, 341);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(75, 23);
            this.btnClearAll.TabIndex = 9;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.trackBarBalance);
            this.groupBox1.Controls.Add(this.lblProgVolume);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.trackBar1);
            this.groupBox1.Location = new System.Drawing.Point(465, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 185);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Volume Controls";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(169, 129);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "R";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "L";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Balance";
            // 
            // trackBarBalance
            // 
            this.trackBarBalance.LargeChange = 10;
            this.trackBarBalance.Location = new System.Drawing.Point(32, 115);
            this.trackBarBalance.Maximum = 100;
            this.trackBarBalance.Minimum = -100;
            this.trackBarBalance.Name = "trackBarBalance";
            this.trackBarBalance.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBarBalance.Size = new System.Drawing.Size(142, 45);
            this.trackBarBalance.TabIndex = 13;
            this.trackBarBalance.TickFrequency = 20;
            this.trackBarBalance.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBarBalance.Scroll += new System.EventHandler(this.trackBarBalance_Scroll);
            // 
            // lblProgVolume
            // 
            this.lblProgVolume.AutoSize = true;
            this.lblProgVolume.Location = new System.Drawing.Point(161, 62);
            this.lblProgVolume.Name = "lblProgVolume";
            this.lblProgVolume.Size = new System.Drawing.Size(25, 13);
            this.lblProgVolume.TabIndex = 9;
            this.lblProgVolume.Text = "100";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Program Volume";
            // 
            // trackBar1
            // 
            this.trackBar1.LargeChange = 10;
            this.trackBar1.Location = new System.Drawing.Point(18, 47);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBar1.Size = new System.Drawing.Size(142, 45);
            this.trackBar1.TabIndex = 7;
            this.trackBar1.TickFrequency = 10;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBar1.Value = 100;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabTracks);
            this.tabControl1.Controls.Add(this.tabOptions);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(684, 407);
            this.tabControl1.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 431);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(700, 470);
            this.Name = "Form1";
            this.Text = "TapeCue v1.0";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabOptions.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabTracks.ResumeLayout(false);
            this.tabTracks.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarScrub)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openProjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveProjectToolStripMenuItem;
        private System.Windows.Forms.TabPage tabOptions;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtGap;
        private System.Windows.Forms.CheckBox checkBoxGap;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnMerge;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnToneB;
        private System.Windows.Forms.Button btnToneA;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtToneDuration;
        private System.Windows.Forms.TextBox txtFreq;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnPurge;
        private System.Windows.Forms.CheckBox checkBoxLogScale;
        private System.Windows.Forms.CheckBox checkBoxFlashWindow;
        private System.Windows.Forms.TabPage tabTracks;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Button btnStartB;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.TrackBar trackBarScrub;
        private System.Windows.Forms.Button btnStartA;
        private System.Windows.Forms.Button btnDelSel;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ListBox listBoxA;
        private System.Windows.Forms.Label lblSideB;
        private System.Windows.Forms.Label lblSideA;
        private System.Windows.Forms.ListBox listBoxB;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TrackBar trackBarBalance;
        private System.Windows.Forms.Label lblProgVolume;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
    }
}

